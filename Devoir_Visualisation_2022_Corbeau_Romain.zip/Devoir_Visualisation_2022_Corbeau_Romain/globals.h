//#define FICHIER MY_MESHES_PATH "/Frog.raw_256_256_44_CHAR.raw"
//
//int gridSize = 256;
//int YgridSize = 256;
//int ZgridSize = 44;
//
//#define CHAR
//
//int startexploreval=13;
//int endexploreval=20;
//bool shouldUseMpi = false;
//
//
//#define FICHIER MY_MESHES_PATH "/Mystere1_512_512_134_SHORT.raw"
//int gridSize = 512;
//int YgridSize = 512;
//int ZgridSize = 134;
//
//#define SHORT
//
//int startexploreval=25000;
//int endexploreval=40000;
//int NbPasses = 5;
//bool shouldUseMpi = false;
//
//
//#define FICHIER MY_MESHES_PATH "/Mystere2_512_400_512_SHORT.raw"
//int gridSize = 512;
//int YgridSize = 400;
//int ZgridSize = 512;
//
//#define SHORT
//
//int startexploreval=25000;
//int endexploreval=35000;
//bool shouldUseMpi = false;
//
//
//#define FICHIER MY_MESHES_PATH "/Mystere4_512_512_322_SHORT.raw"
//int gridSize = 512;
//int YgridSize = 512;
//int ZgridSize = 322;
//
// #define SHORT
//
// int startexploreval=60000;
// int endexploreval=63000;
//bool shouldUseMpi = false;
//
//
#define FICHIER MY_MESHES_PATH "/Mystere5_2048_2048_756_SHORT.raw"

int gridSize = 2048;
int YgridSize = 2048;
int ZgridSize = 756;

#define SHORT

int startexploreval=1;
int endexploreval=65000;
bool shouldUseMpi = true;
//
//
//#define FICHIER MY_MESHES_PATH "/Mystere6_1118_2046_694_CHAR.raw"
//
//int gridSize = 1118;
//int YgridSize = 2046;
//int ZgridSize = 694;
//
//#define CHAR
//
//int startexploreval=1;
//int endexploreval=255;
//bool shouldUseMpi = true;
//
//
//#define FICHIER MY_MESHES_PATH "/Mystere8_2048_2048_2048_SHORT.raw"
//int gridSize = 2048;
//int YgridSize = 2048;
//int ZgridSize = 2048;
//
//#define CHAR
//
//int startexploreval=20000;
//int endexploreval=50000;
//int NbPasses = 5;
//bool shouldUseMpi = true;
//
//
//#define FICHIER MY_MESHES_PATH "/Mystere9_2048_2048_1444_SHORT.raw"
//int gridSize = 2048;
//int YgridSize = 2048;
//int ZgridSize = 1444;
//
//#define SHORT
//
//int startexploreval=20000;
//int endexploreval=50000;
//int NbPasses = 5;
//bool shouldUseMpi = true;
//
//
//#define FICHIER MY_MESHES_PATH "/Mystere10_1204_1296_224_CHAR.raw"
//int gridSize = 1204;
//int YgridSize = 1296;
//int ZgridSize = 224;
//
//#define CHAR
//
//int startexploreval=20000;
//int endexploreval=50000;
//int NbPasses = 5;
//bool shouldUseMpi = true;
//
//
//#define FICHIER MY_MESHES_PATH "/Mystere11_512_512_1024_SHORT.raw"
//int gridSize = 512;
//int YgridSize = 512;
//int ZgridSize = 1024;
//
//#define SHORT
//
//int startexploreval=20000;
//int endexploreval=50000;
//int NbPasses = 5;
//bool shouldUseMpi = true;
